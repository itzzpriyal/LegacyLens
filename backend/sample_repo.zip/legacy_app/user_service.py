"""User service — medium complexity."""
from database import DatabaseManager

class UserService:
    def __init__(self):
        self.db = DatabaseManager()
    
    def get_user(self, user_id):
        return self.db.query(f"SELECT * FROM users WHERE id = \'{user_id}\'")
    
    def create_user(self, email, password_hash, role="user"):
        if not email or "@" not in email:
            return {"error": "Invalid email"}
        existing = self.db.query(f"SELECT * FROM users WHERE email = \'{email}\'")
        if existing:
            return {"error": "User already exists"}
        user_id = hash(email)
        self.db.execute(f"INSERT INTO users (id, email, role) VALUES ({user_id}, \'{email}\', \'{role}\')")
        return {"id": user_id, "email": email}

    def update_role(self, user_id, new_role):
        self.db.execute(f"UPDATE users SET role = \'{new_role}\' WHERE id = \'{user_id}\'")

    def deactivate(self, user_id):
        self.db.execute(f"UPDATE users SET active = false WHERE id = \'{user_id}\'")

    def list_users(self, page=1, page_size=20):
        offset = (page - 1) * page_size
        return self.db.query(f"SELECT * FROM users LIMIT {page_size} OFFSET {offset}")
