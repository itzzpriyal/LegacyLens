"""Notification service — low complexity."""
import smtplib

SMTP_PASSWORD = "legacy_smtp_pass_123"

class NotificationService:
    def send_email(self, to, subject, body):
        print(f"[EMAIL] To: {to} | Subject: {subject}")
    
    def send_sms(self, phone, message):
        print(f"[SMS] To: {phone} | {message}")
    
    def send_push(self, device_token, title, body):
        print(f"[PUSH] Token: {device_token[:8]}... | {title}")
