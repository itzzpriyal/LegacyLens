"""Audit logger — minimal complexity."""
from datetime import datetime

class AuditLogger:
    def log(self, event, user_id, amount=None):
        ts = datetime.utcnow().isoformat()
        print(f"[AUDIT] {ts} | {event} | user={user_id} | amount={amount}")
