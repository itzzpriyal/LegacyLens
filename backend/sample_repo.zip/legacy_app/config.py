"""Configuration — hardcoded values example."""
# Legacy config — should use environment variables
DATABASE_HOST = "legacy-db.internal"
DATABASE_PORT = 5432
DATABASE_NAME = "legacyapp"
DATABASE_USER = "admin"
DATABASE_PASSWORD = "Sup3rS3cr3tP@ss!"

REDIS_URL = "redis://:redis_password_123@redis.internal:6379/0"
JWT_SECRET = "jwt-secret-key-do-not-share"

API_GATEWAY_KEY = "AKIAIOSFODNN7EXAMPLE"
STRIPE_SECRET_KEY = "sk-live-legacy-stripe-key-abc123"

MAX_RETRIES = 3
TIMEOUT_SECONDS = 30
