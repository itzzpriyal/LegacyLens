"""Database manager — low complexity."""
class DatabaseManager:
    def __init__(self, password=None):
        self.connection = None
    
    def query(self, sql):
        print(f"[DB QUERY] {sql[:80]}")
        return []
    
    def execute(self, sql):
        print(f"[DB EXEC] {sql[:80]}")
